//Jason Ronoastro
//Lab 3. 08-09-2020
//Da Vinci College. Software Development

//Code voor de tafel van 6.
var tafel3 = 3;//Alle getallen worden vermedigvulgd met 3.
for(var i=0; i <= 10; i++){//For loop om steeds 1 getal bij te voegen als het kleiner is dan 10 en dan stopt de teller als het bij het getal 10 is.
    var antwoord = tafel3*i;
document.write(tafel3,'x',i,'=', antwoord,'<br/>');//Hier worden de berekeningen met antwoord getoond op het scherm.
};