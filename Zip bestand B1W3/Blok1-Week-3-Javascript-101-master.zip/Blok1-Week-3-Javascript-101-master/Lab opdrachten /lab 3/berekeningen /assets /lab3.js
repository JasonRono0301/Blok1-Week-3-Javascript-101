//Jason Ronoastro
//Lab 3. 08-09-2020.
//Da Vinci College. Software Development.

//3. Berekeningen uitvoeren.
var uitkomst1 = 12+6*10/5-12;//De uitkomst voor de berekening.
document.write(12,'+',6,'x',10,'/',5,'-',12,'=', uitkomst1,'<br/>');//Laat de berekening zien op het scherm.

//4. Berekeningen uitvoeren met invoer van getal.
var invoer = prompt('Type een getal in.');//Promot voor de gebruiker zodat diegene een getal kan invoeren.
var uitkomst2 = invoer + 12+4*5/9-13;
document.write(invoer,'+',12,'+',4,'x',5,'/',9,'-',13,'=', uitkomst1);//Laat de berekening zien op het scherm.
//Het is my opgevallen dat het antwoord hetzelfde is.
